"""
Blender Robot Arm Animation Authoring Pipeline
================================================
Author: David @ Meta Reality Labs / The Fantastic Planet LLC
Purpose: Set up a Franka Panda arm in Blender for keyframing cloth manipulation
         animations across 11 cloth groups, then export to Newton/Isaac Lab format.

Usage:
  1. Open Blender
  2. Open the Scripting workspace
  3. Load and run this script (blender_franka_setup.py)
  4. Use the generated rig to keyframe animations per cloth group
  5. Run the export script (export_trajectories.py) to generate training data

Requirements:
  - Blender 3.6+ (for Python 3.10+ compatibility)
  - Optional: Franka URDF/USD for visual mesh overlay
"""

import bpy
import math
import mathutils
import json
import os
from mathutils import Vector, Matrix, Euler

# =============================================================================
# FRANKA PANDA DH PARAMETERS (Standard Denavit-Hartenberg)
# =============================================================================
# These define the exact kinematic chain of the Franka Emika Panda 7-DOF arm
# Reference: https://frankaemika.github.io/docs/control_parameters.html

FRANKA_DH_PARAMS = {
    "joint_names": [
        "panda_joint1",  # Base rotation (Z-axis)
        "panda_joint2",  # Shoulder pitch
        "panda_joint3",  # Elbow rotation
        "panda_joint4",  # Elbow pitch
        "panda_joint5",  # Wrist rotation
        "panda_joint6",  # Wrist pitch
        "panda_joint7",  # Wrist roll (flange)
    ],
    # Link lengths (meters) — approximate visual segment lengths
    "link_lengths": [0.333, 0.0, 0.316, 0.0825, 0.384, 0.0, 0.107],
    # Joint axis for each joint
    "joint_axes": ["Z", "Y", "Z", "-Y", "Z", "Y", "Z"],
    # Joint limits (radians) — from Franka documentation
    "joint_limits_lower": [-2.8973, -1.7628, -2.8973, -3.0718, -2.8973, -0.0175, -2.8973],
    "joint_limits_upper": [ 2.8973,  1.7628,  2.8973, -0.0698,  2.8973,  3.7525,  2.8973],
    # Default home position (radians)
    "home_position": [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785],
    # Visual bone sizes (for display)
    "bone_radii": [0.04, 0.04, 0.035, 0.035, 0.03, 0.03, 0.025],
}

# Gripper parameters
GRIPPER_PARAMS = {
    "max_width": 0.08,      # 8cm max opening
    "min_width": 0.0,       # fully closed
    "finger_length": 0.045, # finger length
}

# =============================================================================
# 11 CLOTH GROUPS — Define your categories here
# =============================================================================
CLOTH_GROUPS = {
    0:  {"name": "silk_chiffon",     "weight": "ultralight", "stiffness": 0.05, "color": (0.9, 0.8, 0.85, 1.0)},
    1:  {"name": "cotton_tshirt",    "weight": "light",      "stiffness": 0.15, "color": (0.2, 0.5, 0.8, 1.0)},
    2:  {"name": "linen_shirt",      "weight": "light",      "stiffness": 0.25, "color": (0.85, 0.82, 0.75, 1.0)},
    3:  {"name": "polyester_blend",  "weight": "medium",     "stiffness": 0.30, "color": (0.3, 0.3, 0.7, 1.0)},
    4:  {"name": "wool_knit",        "weight": "medium",     "stiffness": 0.40, "color": (0.6, 0.3, 0.2, 1.0)},
    5:  {"name": "terry_towel",      "weight": "medium",     "stiffness": 0.35, "color": (0.9, 0.9, 0.9, 1.0)},
    6:  {"name": "fleece",           "weight": "medium",     "stiffness": 0.45, "color": (0.4, 0.6, 0.3, 1.0)},
    7:  {"name": "denim_light",      "weight": "heavy",      "stiffness": 0.60, "color": (0.2, 0.3, 0.5, 1.0)},
    8:  {"name": "denim_heavy",      "weight": "heavy",      "stiffness": 0.75, "color": (0.15, 0.2, 0.4, 1.0)},
    9:  {"name": "canvas",           "weight": "heavy",      "stiffness": 0.80, "color": (0.6, 0.55, 0.4, 1.0)},
    10: {"name": "leather_thin",     "weight": "heavy",      "stiffness": 0.90, "color": (0.3, 0.15, 0.1, 1.0)},
}


# =============================================================================
# SCENE SETUP
# =============================================================================

def clean_scene():
    """Remove all existing objects."""
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    
    # Remove orphan data
    for collection in [bpy.data.meshes, bpy.data.materials, 
                       bpy.data.armatures, bpy.data.actions]:
        for item in collection:
            collection.remove(item)


def create_table():
    """Create a work table for the cloth manipulation scene."""
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0.5, 0, 0.4))
    table = bpy.context.active_object
    table.name = "WorkTable"
    table.scale = (0.6, 0.8, 0.02)
    
    # Table material
    mat = bpy.data.materials.new(name="TableMaterial")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (0.4, 0.35, 0.3, 1.0)
    bsdf.inputs["Roughness"].default_value = 0.7
    table.data.materials.append(mat)
    
    # Add table legs
    for x, y in [(-0.25, -0.35), (0.25, -0.35), (-0.25, 0.35), (0.25, 0.35)]:
        bpy.ops.mesh.primitive_cylinder_add(radius=0.02, depth=0.78, 
                                             location=(0.5 + x, y, 0.0))
        leg = bpy.context.active_object
        leg.name = f"TableLeg_{x:.0f}_{y:.0f}"
        leg.parent = table
    
    return table


def create_cloth_proxy(group_id, location=(0.5, 0.0, 0.42)):
    """Create a colored plane representing a cloth from a specific group."""
    group = CLOTH_GROUPS[group_id]
    
    bpy.ops.mesh.primitive_plane_add(size=0.3, location=location)
    cloth = bpy.context.active_object
    cloth.name = f"Cloth_{group['name']}"
    
    # Cloth material with group color
    mat = bpy.data.materials.new(name=f"Cloth_{group['name']}_Mat")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = group["color"]
    bsdf.inputs["Roughness"].default_value = 0.8
    cloth.data.materials.append(mat)
    
    # Add custom properties for the cloth group
    cloth["cloth_group_id"] = group_id
    cloth["cloth_group_name"] = group["name"]
    cloth["cloth_stiffness"] = group["stiffness"]
    cloth["cloth_weight_class"] = group["weight"]
    
    return cloth


# =============================================================================
# FRANKA ARM RIG CREATION
# =============================================================================

def create_franka_armature():
    """
    Create a Franka Panda arm as a Blender armature with proper joint axes,
    limits, and custom bone shapes for intuitive animation.
    
    The rig uses FK (Forward Kinematics) controls since we want to export
    joint-space trajectories for the robot. Each bone corresponds to one
    robot joint.
    """
    # Create armature
    arm_data = bpy.data.armatures.new("FrankaArmature")
    arm_data.display_type = 'STICK'
    arm_obj = bpy.data.objects.new("FrankaPanda", arm_data)
    bpy.context.collection.objects.link(arm_obj)
    bpy.context.view_layer.objects.active = arm_obj
    arm_obj.location = (0, 0, 0)  # Base at origin
    
    # Enter edit mode to create bones
    bpy.ops.object.mode_set(mode='EDIT')
    
    # Bone positions along the kinematic chain
    # These approximate the Franka's link positions
    bone_chain = [
        # (name, head_z, tail_z, head_offset_xy, tail_offset_xy)
        ("Base",    0.0,    0.333,  (0, 0),      (0, 0)),
        ("Link1",   0.333,  0.333,  (0, 0),      (0, 0.316)),
        ("Link2",   0.333,  0.649,  (0, 0),      (0, 0)),
        ("Link3",   0.649,  0.649,  (0, 0),      (0.0825, 0)),
        ("Link4",   0.649,  1.033,  (0, 0),      (0, 0)),
        ("Link5",   1.033,  1.033,  (0, 0),      (0, 0)),
        ("Link6",   1.033,  1.14,   (0, 0),      (0, 0)),
    ]
    
    # Create bones with proper parent chain
    edit_bones = arm_data.edit_bones
    prev_bone = None
    
    # Create a vertical chain approximating Franka geometry
    positions = [
        Vector((0, 0, 0)),         # joint1: base
        Vector((0, 0, 0.333)),     # joint2: shoulder
        Vector((0, 0, 0.333)),     # joint3: at shoulder (rotation)
        Vector((0, 0, 0.649)),     # joint4: elbow
        Vector((0, 0, 0.649)),     # joint5: at elbow (rotation)
        Vector((0, 0, 1.033)),     # joint6: wrist
        Vector((0, 0, 1.033)),     # joint7: wrist roll
        Vector((0, 0, 1.14)),      # end effector
    ]
    
    bone_names = FRANKA_DH_PARAMS["joint_names"]
    bones = []
    
    for i, name in enumerate(bone_names):
        bone = edit_bones.new(name)
        bone.head = positions[i]
        bone.tail = positions[i + 1]
        
        # Minimum bone length for Blender visibility
        if (bone.tail - bone.head).length < 0.01:
            bone.tail = bone.head + Vector((0, 0, 0.05))
        
        if prev_bone:
            bone.parent = prev_bone
            bone.use_connect = False
        
        prev_bone = bone
        bones.append(bone)
    
    # Add gripper bones
    ee_pos = positions[-1]
    
    # Gripper base
    gripper_base = edit_bones.new("gripper_base")
    gripper_base.head = ee_pos
    gripper_base.tail = ee_pos + Vector((0, 0, 0.02))
    gripper_base.parent = prev_bone
    
    # Left finger
    finger_l = edit_bones.new("finger_left")
    finger_l.head = ee_pos + Vector((0, -0.02, 0.02))
    finger_l.tail = ee_pos + Vector((0, -0.02, 0.02 + GRIPPER_PARAMS["finger_length"]))
    finger_l.parent = gripper_base
    
    # Right finger
    finger_r = edit_bones.new("finger_right")
    finger_r.head = ee_pos + Vector((0, 0.02, 0.02))
    finger_r.tail = ee_pos + Vector((0, 0.02, 0.02 + GRIPPER_PARAMS["finger_length"]))
    finger_r.parent = gripper_base
    
    # Switch to pose mode and set up constraints
    bpy.ops.object.mode_set(mode='POSE')
    
    # Set joint limits on each bone
    for i, name in enumerate(bone_names):
        pose_bone = arm_obj.pose.bones[name]
        
        # Lock axes that shouldn't rotate
        axis = FRANKA_DH_PARAMS["joint_axes"][i]
        if axis in ("Z", "-Z"):
            pose_bone.lock_rotation = [True, True, False]   # only Z rotates
            pose_bone.lock_location = [True, True, True]
        elif axis in ("Y", "-Y"):
            pose_bone.lock_rotation = [True, False, True]   # only Y rotates
            pose_bone.lock_location = [True, True, True]
        
        # Add rotation limits
        constraint = pose_bone.constraints.new('LIMIT_ROTATION')
        constraint.use_limit_x = True
        constraint.use_limit_y = True
        constraint.use_limit_z = True
        constraint.owner_space = 'LOCAL'
        
        lower = FRANKA_DH_PARAMS["joint_limits_lower"][i]
        upper = FRANKA_DH_PARAMS["joint_limits_upper"][i]
        
        if axis in ("Z", "-Z"):
            constraint.min_z = lower
            constraint.max_z = upper
        elif axis in ("Y", "-Y"):
            constraint.min_y = lower
            constraint.max_y = upper
        
        # Color coding by joint group
        # Shoulder (1-2): Red, Elbow (3-4): Green, Wrist (5-7): Blue
        if i < 2:
            pose_bone.color.palette = 'THEME01'  # Red
        elif i < 4:
            pose_bone.color.palette = 'THEME04'  # Green
        else:
            pose_bone.color.palette = 'THEME06'  # Blue
    
    # Set up gripper with a driver for open/close
    # Use a custom property on the armature to control gripper width
    arm_obj["gripper_width"] = GRIPPER_PARAMS["max_width"] / 2.0
    
    # Configure property range
    ui = arm_obj.id_properties_ui("gripper_width")
    ui.update(min=0.0, max=GRIPPER_PARAMS["max_width"], soft_min=0.0, 
              soft_max=GRIPPER_PARAMS["max_width"])
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return arm_obj


def add_visual_meshes(arm_obj):
    """
    Add simple visual meshes to the arm bones for better viewport feedback.
    These are approximate cylinders/boxes representing each link.
    """
    link_visuals = [
        {"name": "base_visual",   "type": "cylinder", "radius": 0.06, "height": 0.333, 
         "offset": (0, 0, 0.1665), "color": (0.8, 0.8, 0.8, 1)},
        {"name": "link1_visual",  "type": "cylinder", "radius": 0.05, "height": 0.316, 
         "offset": (0, 0, 0.491), "color": (0.9, 0.9, 0.9, 1)},
        {"name": "link3_visual",  "type": "cylinder", "radius": 0.045, "height": 0.384, 
         "offset": (0, 0, 0.841), "color": (0.8, 0.8, 0.8, 1)},
        {"name": "link5_visual",  "type": "cylinder", "radius": 0.04, "height": 0.107, 
         "offset": (0, 0, 1.0865), "color": (0.9, 0.9, 0.9, 1)},
    ]
    
    for vis in link_visuals:
        if vis["type"] == "cylinder":
            bpy.ops.mesh.primitive_cylinder_add(
                radius=vis["radius"], depth=vis["height"],
                location=vis["offset"]
            )
        mesh = bpy.context.active_object
        mesh.name = vis["name"]
        
        # Parent to armature with armature deform
        mesh.parent = arm_obj
        modifier = mesh.modifiers.new(name="Armature", type='ARMATURE')
        modifier.object = arm_obj
        
        # Material
        mat = bpy.data.materials.new(name=f"{vis['name']}_mat")
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        bsdf.inputs["Base Color"].default_value = vis["color"]
        bsdf.inputs["Metallic"].default_value = 0.3
        bsdf.inputs["Roughness"].default_value = 0.4
        mesh.data.materials.append(mat)


def set_home_position(arm_obj):
    """Set the arm to its home (default) position."""
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode='POSE')
    
    home = FRANKA_DH_PARAMS["home_position"]
    axes = FRANKA_DH_PARAMS["joint_axes"]
    
    for i, name in enumerate(FRANKA_DH_PARAMS["joint_names"]):
        pose_bone = arm_obj.pose.bones[name]
        pose_bone.rotation_mode = 'XYZ'
        
        angle = home[i]
        axis = axes[i]
        
        if axis == "Z":
            pose_bone.rotation_euler = (0, 0, angle)
        elif axis == "-Z":
            pose_bone.rotation_euler = (0, 0, -angle)
        elif axis == "Y":
            pose_bone.rotation_euler = (0, angle, 0)
        elif axis == "-Y":
            pose_bone.rotation_euler = (0, -angle, 0)
    
    bpy.ops.object.mode_set(mode='OBJECT')


# =============================================================================
# NLA ACTION SETUP — One action per cloth group
# =============================================================================

def create_group_actions(arm_obj):
    """
    Create an NLA action (animation clip) for each of the 11 cloth groups.
    Each action is pre-populated with a basic pick-and-place template that
    the animator can then customize per group.
    
    The template varies approach speed, grasp timing, and lift profile
    based on the cloth group's stiffness/weight properties.
    """
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode='POSE')
    
    fps = bpy.context.scene.render.fps  # typically 24 or 30
    
    for group_id, group_info in CLOTH_GROUPS.items():
        action_name = f"ClothGroup_{group_id:02d}_{group_info['name']}"
        action = bpy.data.actions.new(name=action_name)
        action.use_fake_user = True  # prevent garbage collection
        
        # Tag the action with cloth group metadata
        action["cloth_group_id"] = group_id
        action["cloth_group_name"] = group_info["name"]
        action["cloth_stiffness"] = group_info["stiffness"]
        action["cloth_weight_class"] = group_info["weight"]
        
        # Assign action to armature temporarily for keyframing
        arm_obj.animation_data_create()
        arm_obj.animation_data.action = action
        
        # Calculate timing based on cloth properties
        # Heavier/stiffer cloth = slower movements
        stiffness = group_info["stiffness"]
        speed_factor = 1.0 + stiffness  # 1.05 for silk, 1.9 for leather
        
        # Keyframe timing (in frames at scene FPS)
        frames = {
            "start":        1,
            "approach":     int(15 * speed_factor),
            "pre_grasp":    int(25 * speed_factor),
            "grasp":        int(30 * speed_factor),
            "post_grasp":   int(35 * speed_factor),
            "lift":         int(50 * speed_factor),
            "transport":    int(70 * speed_factor),
            "pre_place":    int(85 * speed_factor),
            "place":        int(95 * speed_factor),
            "release":      int(100 * speed_factor),
            "retreat":      int(110 * speed_factor),
        }
        
        # ---- KEYFRAME: Start (Home Position) ----
        bpy.context.scene.frame_set(frames["start"])
        set_home_position(arm_obj)
        for bone_name in FRANKA_DH_PARAMS["joint_names"]:
            arm_obj.pose.bones[bone_name].keyframe_insert(
                data_path="rotation_euler", frame=frames["start"]
            )
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["start"])
        
        # ---- KEYFRAME: Approach ----
        # Vary approach angle based on cloth type
        bpy.context.scene.frame_set(frames["approach"])
        approach_configs = {
            "ultralight": {"j2": -1.2, "j4": -2.0, "j6": 2.0},  # steep approach
            "light":      {"j2": -1.0, "j4": -2.1, "j6": 1.8},
            "medium":     {"j2": -0.9, "j4": -2.2, "j6": 1.6},
            "heavy":      {"j2": -0.7, "j4": -2.4, "j6": 1.4},  # more horizontal
        }
        config = approach_configs[group_info["weight"]]
        
        joints = FRANKA_DH_PARAMS["joint_names"]
        axes = FRANKA_DH_PARAMS["joint_axes"]
        
        # Set approach pose
        pose_values = [0.0, config["j2"], 0.0, config["j4"], 0.0, config["j6"], 0.785]
        for i, name in enumerate(joints):
            pb = arm_obj.pose.bones[name]
            axis = axes[i]
            val = pose_values[i]
            if axis in ("Z", "-Z"):
                pb.rotation_euler = (0, 0, val if axis == "Z" else -val)
            elif axis in ("Y", "-Y"):
                pb.rotation_euler = (0, val if axis == "Y" else -val, 0)
            pb.keyframe_insert(data_path="rotation_euler", frame=frames["approach"])
        
        # Gripper open during approach
        arm_obj["gripper_width"] = GRIPPER_PARAMS["max_width"]
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["approach"])
        
        # ---- KEYFRAME: Grasp ----
        bpy.context.scene.frame_set(frames["grasp"])
        # Close gripper — width depends on cloth thickness
        grip_widths = {
            "ultralight": 0.002,  # barely closed
            "light":      0.005,
            "medium":     0.008,
            "heavy":      0.012,
        }
        arm_obj["gripper_width"] = grip_widths[group_info["weight"]]
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["grasp"])
        
        # ---- KEYFRAME: Lift ----
        bpy.context.scene.frame_set(frames["lift"])
        # Lift height varies — stretchy cloth needs higher lift
        lift_configs = {
            "ultralight": {"j2": -0.5, "j4": -1.8, "j6": 1.5},
            "light":      {"j2": -0.6, "j4": -1.9, "j6": 1.5},
            "medium":     {"j2": -0.7, "j4": -2.0, "j6": 1.5},
            "heavy":      {"j2": -0.8, "j4": -2.1, "j6": 1.4},
        }
        lconfig = lift_configs[group_info["weight"]]
        lift_values = [0.0, lconfig["j2"], 0.0, lconfig["j4"], 0.0, lconfig["j6"], 0.785]
        for i, name in enumerate(joints):
            pb = arm_obj.pose.bones[name]
            axis = axes[i]
            val = lift_values[i]
            if axis in ("Z", "-Z"):
                pb.rotation_euler = (0, 0, val if axis == "Z" else -val)
            elif axis in ("Y", "-Y"):
                pb.rotation_euler = (0, val if axis == "Y" else -val, 0)
            pb.keyframe_insert(data_path="rotation_euler", frame=frames["lift"])
        
        # Gripper stays closed
        arm_obj["gripper_width"] = grip_widths[group_info["weight"]]
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["lift"])
        
        # ---- KEYFRAME: Place / Release ----
        bpy.context.scene.frame_set(frames["release"])
        arm_obj["gripper_width"] = GRIPPER_PARAMS["max_width"]
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["release"])
        
        # ---- KEYFRAME: Retreat (back to home) ----
        bpy.context.scene.frame_set(frames["retreat"])
        set_home_position(arm_obj)
        for bone_name in joints:
            arm_obj.pose.bones[bone_name].keyframe_insert(
                data_path="rotation_euler", frame=frames["retreat"]
            )
        arm_obj.keyframe_insert(data_path='["gripper_width"]', frame=frames["retreat"])
        
        # Set interpolation to smooth (Bezier) for all keyframes
        if action.fcurves:
            for fcurve in action.fcurves:
                for keyframe in fcurve.keyframe_points:
                    keyframe.interpolation = 'BEZIER'
                    keyframe.handle_left_type = 'AUTO_CLAMPED'
                    keyframe.handle_right_type = 'AUTO_CLAMPED'
        
        print(f"  Created action: {action_name} "
              f"({frames['retreat']} frames, {frames['retreat']/fps:.1f}s)")
    
    # Push all actions to NLA strips for easy management
    arm_obj.animation_data.action = None  # clear active action
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    print(f"\nCreated {len(CLOTH_GROUPS)} animation actions.")
    print("Use the NLA Editor or Action Editor to switch between cloth groups.")


# =============================================================================
# HELPER: Create annotation markers in the timeline
# =============================================================================

def create_timeline_markers():
    """Add markers to the timeline for common keyframe phases."""
    scene = bpy.context.scene
    markers = scene.timeline_markers
    markers.clear()
    
    # These are reference markers — actual frame numbers depend on the active action
    phase_names = [
        (1,   "HOME"),
        (15,  "APPROACH"),
        (25,  "PRE_GRASP"),
        (30,  "GRASP"),
        (35,  "POST_GRASP"),
        (50,  "LIFT"),
        (70,  "TRANSPORT"),
        (85,  "PRE_PLACE"),
        (95,  "PLACE"),
        (100, "RELEASE"),
        (110, "RETREAT"),
    ]
    
    for frame, name in phase_names:
        marker = markers.new(name, frame=frame)


# =============================================================================
# MAIN SETUP
# =============================================================================

def setup_scene():
    """Main function to set up the complete Blender scene."""
    print("=" * 60)
    print("FRANKA ARM — CLOTH MANIPULATION ANIMATION SETUP")
    print("=" * 60)
    
    # Clean slate
    print("\n[1/6] Cleaning scene...")
    clean_scene()
    
    # Scene settings
    bpy.context.scene.render.fps = 30
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = 250
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.unit_settings.length_unit = 'METERS'
    
    # Create environment
    print("[2/6] Creating table...")
    table = create_table()
    
    # Create cloth proxies (one visible at a time)
    print("[3/6] Creating cloth proxy objects...")
    cloth_collection = bpy.data.collections.new("ClothProxies")
    bpy.context.scene.collection.children.link(cloth_collection)
    
    for gid in CLOTH_GROUPS:
        cloth = create_cloth_proxy(gid, location=(0.5, 0.0, 0.42))
        # Move to cloth collection
        bpy.context.scene.collection.objects.unlink(cloth)
        cloth_collection.objects.link(cloth)
        # Hide all but group 0
        cloth.hide_viewport = (gid != 0)
        cloth.hide_render = (gid != 0)
    
    # Create arm rig
    print("[4/6] Creating Franka arm rig...")
    arm_obj = create_franka_armature()
    set_home_position(arm_obj)
    
    # Create per-group animation actions
    print("[5/6] Creating animation actions for 11 cloth groups...")
    create_group_actions(arm_obj)
    
    # Timeline markers
    print("[6/6] Adding timeline markers...")
    create_timeline_markers()
    
    # Set up camera and lighting
    bpy.ops.object.camera_add(location=(1.5, -1.5, 1.2))
    cam = bpy.context.active_object
    cam.name = "AnimationCamera"
    cam.rotation_euler = (math.radians(60), 0, math.radians(45))
    bpy.context.scene.camera = cam
    
    bpy.ops.object.light_add(type='SUN', location=(2, -2, 3))
    light = bpy.context.active_object
    light.name = "KeyLight"
    light.data.energy = 3.0
    
    # Final selection
    bpy.context.view_layer.objects.active = arm_obj
    arm_obj.select_set(True)
    
    print("\n" + "=" * 60)
    print("SETUP COMPLETE!")
    print("=" * 60)
    print(f"""
WORKFLOW:
  1. Select the FrankaPanda armature
  2. Open the Action Editor (Shift+F6)
  3. Browse actions — one per cloth group:
     - ClothGroup_00_silk_chiffon
     - ClothGroup_01_cotton_tshirt
     - ...
     - ClothGroup_10_leather_thin
  4. Switch to Pose Mode (Ctrl+Tab)
  5. Adjust keyframes per group to match desired motion
  6. Use the Dope Sheet / Graph Editor for timing curves
  7. Toggle cloth proxies in the Outliner (ClothProxies collection)
  
EXPORT:
  Run export_trajectories.py to generate:
  - Joint-space trajectories (for Isaac Lab)
  - End-effector Cartesian paths (for IK policies)
  - Gripper commands per group
  - DMP parameters fitted to each action

TIPS:
  - The arm uses FK (Forward Kinematics) for direct joint control
  - Each bone only rotates on its physical axis (others are locked)
  - Joint limits match the real Franka Panda specifications
  - Gripper width is a custom property — keyframe it directly
  - Use Bezier curve handles in the Graph Editor to shape easing
  - Timeline markers show the manipulation phases
""")


# Run setup
if __name__ == "__main__":
    setup_scene()
